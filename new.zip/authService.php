<?php

require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/config.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/database.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/interactWithDatabase.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/JWT.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/interactWithJWT.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/new/classes/passwordLib.php');





$start = new createMockData();


?>