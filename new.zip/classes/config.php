<?php 

define("databaseName", "authService");
define("authName", "exampleService");
define("hashSalt", "da39a3ee5e6b4b0d3255bfef95601890afd80709");
define("secretKey", "c3dee78510a7f3695bb5453ac373a84f80b89de6");
    
    ?>